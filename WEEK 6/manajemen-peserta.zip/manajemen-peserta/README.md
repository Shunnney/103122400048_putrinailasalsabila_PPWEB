# Aplikasi Manajemen Peserta Praktikum

Praktikum Pemrograman Web Modul 06 - React Dasar (React + JavaScript + Vite).

## Cara menjalankan

```bash
npm install
npm run dev
```

Buka alamat yang muncul di terminal (biasanya http://localhost:5173).

Cek build produksi:

```bash
npm run build
```

## Struktur

- `src/App.jsx` - state utama (data, form, mode edit, pencarian, filter, pesan) dan semua event handler
- `src/components/FormPeserta.jsx` - form tambah/ubah peserta
- `src/components/FilterPeserta.jsx` - pencarian dan filter kelas
- `src/components/DaftarPeserta.jsx` - render daftar dengan `map()` dan `key`
- `src/components/ItemPeserta.jsx` - satu peserta + tombol Edit, Hapus, kehadiran
- `src/components/RingkasanPeserta.jsx` - empat angka ringkasan

Data hanya disimpan di state; muat ulang halaman mengembalikan data awal.
