function RingkasanPeserta({ total, hadir, belumHadir, ditampilkan }) {
  const item = [
    { label: 'Total peserta', nilai: total },
    { label: 'Hadir', nilai: hadir },
    { label: 'Belum hadir', nilai: belumHadir },
    { label: 'Hasil ditampilkan', nilai: ditampilkan },
  ]

  return (
    <div className="ringkasan">
      {item.map((i) => (
        <div className="kartu-ringkasan" key={i.label}>
          <span className="ringkasan-label">{i.label}</span>
          <strong className="ringkasan-nilai">{i.nilai}</strong>
        </div>
      ))}
    </div>
  )
}

export default RingkasanPeserta
