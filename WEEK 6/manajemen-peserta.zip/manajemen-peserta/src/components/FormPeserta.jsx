function FormPeserta({ form, modeEdit, pesan, onUbah, onSubmit, onBatal }) {
  return (
    <form className="form" onSubmit={onSubmit} noValidate>
      <h2>{modeEdit ? 'Ubah peserta' : 'Tambah peserta'}</h2>

      <label>
        Nama mahasiswa
        <input
          type="text"
          value={form.nama}
          placeholder="Nama mahasiswa"
          onChange={(e) => onUbah('nama', e.target.value)}
        />
      </label>

      <label>
        NIM
        <input
          type="text"
          inputMode="numeric"
          value={form.nim}
          placeholder="8 digit NIM"
          onChange={(e) => onUbah('nim', e.target.value)}
        />
      </label>

      <label>
        Kelas
        <select value={form.kelas} onChange={(e) => onUbah('kelas', e.target.value)}>
          <option value="">Pilih kelas</option>
          <option value="TI-2A">TI-2A</option>
          <option value="TI-2B">TI-2B</option>
        </select>
      </label>

      {pesan.length > 0 && (
        <ul className="pesan-galat" role="alert">
          {pesan.map((m) => (
            <li key={m}>{m}</li>
          ))}
        </ul>
      )}

      <div className="aksi-form">
        <button type="submit" className="btn btn-utama">
          {modeEdit ? 'Simpan perubahan' : 'Tambah peserta'}
        </button>
        {modeEdit && (
          <button type="button" className="btn" onClick={onBatal}>
            Batal
          </button>
        )}
      </div>
    </form>
  )
}

export default FormPeserta
