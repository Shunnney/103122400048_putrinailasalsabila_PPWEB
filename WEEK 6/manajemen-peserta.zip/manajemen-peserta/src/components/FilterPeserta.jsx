function FilterPeserta({ cari, filterKelas, onCari, onFilterKelas }) {
  return (
    <div className="filter">
      <h2>Cari &amp; filter</h2>

      <label>
        Cari nama atau NIM
        <input
          type="text"
          value={cari}
          placeholder="Ketik nama atau NIM"
          onChange={(e) => onCari(e.target.value)}
        />
      </label>

      <label>
        Filter kelas
        <select value={filterKelas} onChange={(e) => onFilterKelas(e.target.value)}>
          <option value="Semua kelas">Semua kelas</option>
          <option value="TI-2A">TI-2A</option>
          <option value="TI-2B">TI-2B</option>
        </select>
      </label>
    </div>
  )
}

export default FilterPeserta
