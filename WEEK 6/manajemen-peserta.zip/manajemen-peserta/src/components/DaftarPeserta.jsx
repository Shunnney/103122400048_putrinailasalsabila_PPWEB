import ItemPeserta from './ItemPeserta.jsx'

function DaftarPeserta({ daftar, adaData, editId, onEdit, onHapus, onKehadiran }) {
  if (!adaData) {
    return (
      <div>
        <h2>Daftar peserta</h2>
        <p className="kosong">Belum ada peserta</p>
      </div>
    )
  }

  if (daftar.length === 0) {
    return (
      <div>
        <h2>Daftar peserta</h2>
        <p className="kosong">Peserta tidak ditemukan</p>
      </div>
    )
  }

  return (
    <div>
      <h2>Daftar peserta</h2>
      <ul className="daftar">
        {daftar.map((p) => (
          <ItemPeserta
            key={p.id}
            peserta={p}
            sedangDiedit={p.id === editId}
            onEdit={onEdit}
            onHapus={onHapus}
            onKehadiran={onKehadiran}
          />
        ))}
      </ul>
    </div>
  )
}

export default DaftarPeserta
