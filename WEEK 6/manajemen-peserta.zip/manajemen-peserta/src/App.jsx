import { useRef, useState } from 'react'
import RingkasanPeserta from './components/RingkasanPeserta.jsx'
import FormPeserta from './components/FormPeserta.jsx'
import FilterPeserta from './components/FilterPeserta.jsx'
import DaftarPeserta from './components/DaftarPeserta.jsx'

const DATA_AWAL = [
  { id: 'm-1', nama: 'Ani', nim: '10121001', kelas: 'TI-2A', hadir: true },
  { id: 'm-2', nama: 'Budi', nim: '10121002', kelas: 'TI-2B', hadir: false },
  { id: 'm-3', nama: 'Citra', nim: '10121003', kelas: 'TI-2A', hadir: false },
]

const FORM_KOSONG = { nama: '', nim: '', kelas: '' }
const KELAS_VALID = ['TI-2A', 'TI-2B']

function App() {
  const [peserta, setPeserta] = useState(DATA_AWAL)
  const [form, setForm] = useState(FORM_KOSONG)
  const [editId, setEditId] = useState(null)
  const [cari, setCari] = useState('')
  const [filterKelas, setFilterKelas] = useState('Semua kelas')
  const [pesan, setPesan] = useState([])

  // Penghitung ID monotonik agar ID baru tidak pernah bentrok setelah penghapusan.
  const idBerikutnya = useRef(DATA_AWAL.length + 1)

  // ---------- Form ----------
  function ubahForm(field, nilai) {
    setForm({ ...form, [field]: nilai })
  }

  function resetForm() {
    setForm(FORM_KOSONG)
    setEditId(null)
    setPesan([])
  }

  function validasi(nama, nim, kelas) {
    const galat = []
    if (nama.length === 0) galat.push('Nama wajib diisi.')
    else if (nama.length < 3) galat.push('Nama minimal 3 karakter.')

    if (nim.length === 0) galat.push('NIM wajib diisi.')
    else if (!/^\d{8}$/.test(nim)) galat.push('NIM harus terdiri atas tepat 8 digit angka.')
    else if (peserta.some((p) => p.nim === nim && p.id !== editId)) {
      galat.push('NIM ' + nim + ' sudah digunakan peserta lain.')
    }

    if (!KELAS_VALID.includes(kelas)) galat.push('Kelas wajib dipilih (TI-2A atau TI-2B).')
    return galat
  }

  function kirimForm(e) {
    e.preventDefault()
    const nama = form.nama.trim()
    const nim = form.nim.trim()
    const kelas = form.kelas

    const galat = validasi(nama, nim, kelas)
    if (galat.length > 0) {
      setPesan(galat) // data dan isi form tetap tersedia
      return
    }

    if (editId === null) {
      const baru = {
        id: 'm-' + idBerikutnya.current,
        nama,
        nim,
        kelas,
        hadir: false,
      }
      idBerikutnya.current += 1
      setPeserta([...peserta, baru])
    } else {
      setPeserta(
        peserta.map((p) => (p.id === editId ? { ...p, nama, nim, kelas } : p)),
      )
    }
    resetForm()
  }

  function mulaiEdit(id) {
    const target = peserta.find((p) => p.id === id)
    if (!target) return
    setForm({ nama: target.nama, nim: target.nim, kelas: target.kelas })
    setEditId(id)
    setPesan([])
  }

  // ---------- Hapus & kehadiran ----------
  function hapusPeserta(id) {
    setPeserta(peserta.filter((p) => p.id !== id))
    if (editId === id) resetForm()
  }

  function ubahKehadiran(id) {
    setPeserta(peserta.map((p) => (p.id === id ? { ...p, hadir: !p.hadir } : p)))
  }

  // ---------- Pencarian & filter (hanya tampilan) ----------
  const kataCari = cari.trim().toLowerCase()
  const terlihat = peserta.filter((p) => {
    const cocokCari =
      kataCari === '' ||
      p.nama.toLowerCase().includes(kataCari) ||
      p.nim.includes(kataCari)
    const cocokKelas = filterKelas === 'Semua kelas' || p.kelas === filterKelas
    return cocokCari && cocokKelas
  })

  // ---------- Ringkasan (dari seluruh data) ----------
  const total = peserta.length
  const jumlahHadir = peserta.filter((p) => p.hadir).length

  return (
    <div className="app">
      <header className="app-header">
        <h1>Manajemen Peserta Praktikum</h1>
        <RingkasanPeserta
          total={total}
          hadir={jumlahHadir}
          belumHadir={total - jumlahHadir}
          ditampilkan={terlihat.length}
        />
      </header>

      <main>
        <section className="panel">
          <FormPeserta
            form={form}
            modeEdit={editId !== null}
            pesan={pesan}
            onUbah={ubahForm}
            onSubmit={kirimForm}
            onBatal={resetForm}
          />
          <FilterPeserta
            cari={cari}
            filterKelas={filterKelas}
            onCari={setCari}
            onFilterKelas={setFilterKelas}
          />
        </section>

        <section className="panel">
          <DaftarPeserta
            daftar={terlihat}
            adaData={peserta.length > 0}
            editId={editId}
            onEdit={mulaiEdit}
            onHapus={hapusPeserta}
            onKehadiran={ubahKehadiran}
          />
        </section>
      </main>
    </div>
  )
}

export default App
